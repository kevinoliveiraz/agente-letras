# Formatação e paginação

Confirmar papel, fonte, margens, recuos, alinhamento, entrelinhas, paginação e quebras no manual institucional. Na falta dele, aplicar padrão ABNT vigente e guia confiável. Não assumir que toda instituição usa os mesmos detalhes.

