# Sumário

Reproduzir títulos, grafia, hierarquia e páginas exatamente como aparecem no texto. Não confundir sumário com índice. Usar numeração progressiva apenas onde previsto e atualizar o sumário após a paginação final.

