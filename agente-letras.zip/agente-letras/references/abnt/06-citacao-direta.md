# Citação direta

Reproduzir fielmente o original. Distinguir citação curta e longa. Informar autoria, ano e página ou localização exigida. Marcar supressões, acréscimos, ênfases e traduções segundo a norma vigente.

