# Notas, apêndices e anexos

Usar nota de rodapé para informação complementar, sem deslocar argumento essencial. Distinguir apêndice produzido pelo autor de anexo produzido por terceiro. Identificar e mencionar ambos no corpo quando relevantes.

