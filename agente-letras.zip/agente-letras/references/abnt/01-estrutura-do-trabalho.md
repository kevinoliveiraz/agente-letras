# Estrutura do trabalho

Organizar elementos externos, pré-textuais, textuais e pós-textuais. Confirmar quais são obrigatórios para o tipo de trabalho. Não inserir elemento opcional sem necessidade ou omitir requisito institucional.

