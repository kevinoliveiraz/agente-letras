# Citação indireta

Parafrasear com redação própria sem distorcer o autor. Indicar a fonte mesmo sem transcrição literal. Não fazer paráfrase superficial trocando poucas palavras. Preservar grau de certeza e contexto da fonte.

