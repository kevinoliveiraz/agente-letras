# Fontes digitais e multimídia

Formatar sites, posts, vídeos, podcasts, redes sociais, apresentações e documentos digitais conforme elementos disponíveis. Registrar URL e data de acesso quando exigidas. Preferir DOI ou endereço persistente.

