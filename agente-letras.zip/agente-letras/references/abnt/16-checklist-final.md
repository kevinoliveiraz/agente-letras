# Checklist acadêmico final

Conferir estrutura obrigatória, hierarquia, paginação, sumário, títulos, citações, referências, figuras, tabelas, siglas, ortografia e template institucional. Renderizar DOCX ou PDF e verificar visualmente antes de entregar.

