# Índice ABNT

Aplicar primeiro o manual da instituição, depois a norma vigente e, por fim, guias práticos. Consultar o portal indicado pelo usuário: https://normas-abnt.espm.br/.

Módulos: estrutura, capa, folha de rosto, resumo, sumário, seções, citações, referências, figuras, tabelas, notas, paginação e revisão final.

