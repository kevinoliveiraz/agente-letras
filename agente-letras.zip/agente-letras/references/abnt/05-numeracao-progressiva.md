# Numeração progressiva

Hierarquizar seções com algarismos arábicos e diferenciação tipográfica consistente. Não usar pontuação entre indicativo e título. Evitar subdivisão sem conteúdo suficiente ou seção única dentro de um nível.

