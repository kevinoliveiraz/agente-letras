# Citação de citação e informação verbal

Usar apud somente quando o original não puder ser consultado e identificar as duas obras conforme a norma. Registrar informação verbal, entrevista ou comunicação pessoal com os elementos disponíveis e as limitações de recuperabilidade.

