# Tabelas

Usar tabela para dados numéricos ou estatísticos. Aplicar título, numeração, fonte, notas e convenções do IBGE ou manual adotado. Repetir cabeçalho e indicar continuação quando ocupar mais de uma página.

