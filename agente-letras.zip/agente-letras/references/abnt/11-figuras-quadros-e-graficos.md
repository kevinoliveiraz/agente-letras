# Figuras, quadros e gráficos

Numerar, titular e citar a fonte, inclusive quando elaborados pelo autor. Posicionar próximo da primeira menção e explicar no texto. Garantir legibilidade, unidade visual e descrição acessível quando necessária.

