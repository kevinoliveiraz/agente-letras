# Capa e folha de rosto

Incluir identificação exigida na ordem do manual: instituição, autoria, título, subtítulo, natureza, orientação, local e ano, conforme aplicável. Distinguir capa de folha de rosto e aplicar alinhamentos específicos.

