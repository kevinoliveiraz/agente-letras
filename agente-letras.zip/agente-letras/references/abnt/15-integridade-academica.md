# Integridade acadêmica

Não fabricar fonte, citação, dado, página, DOI ou resultado. Distinguir contribuição do autor, paráfrase e transcrição. Alertar sobre plágio, fonte não consultada, referência incompleta e afirmação sem sustentação.

