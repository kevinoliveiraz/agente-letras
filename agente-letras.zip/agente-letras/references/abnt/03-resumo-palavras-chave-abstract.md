# Resumo, palavras-chave e abstract

Redigir resumo autônomo com objetivo, método, resultados e conclusão quando o gênero exigir. Evitar citações e informações ausentes do trabalho. Selecionar palavras-chave representativas. Garantir equivalência de conteúdo no abstract.

