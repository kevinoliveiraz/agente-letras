# Referências

Construir cada referência segundo o tipo documental e a norma vigente. Não inventar dado ausente. Padronizar autoria, título, edição, local, editora, data, DOI, URL e acesso. Conferir correspondência bidirecional entre citações e lista.

