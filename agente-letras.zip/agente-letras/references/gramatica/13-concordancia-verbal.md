# Concordância verbal

Fazer o verbo concordar com o núcleo do sujeito. Verificar sujeito composto, porcentagens, coletivos, pronomes relativos, expressões partitivas, verbo ser, haver impessoal e fazer indicando tempo. Considerar variantes aceitas sem apresentar preferência como regra absoluta.

