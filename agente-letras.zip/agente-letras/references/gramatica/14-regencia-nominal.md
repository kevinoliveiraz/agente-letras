# Regência nominal

Confirmar a preposição exigida por substantivo, adjetivo ou advérbio. Não escolher preposição apenas por analogia. Em uso técnico ou construção rara, consultar fonte normativa ou dicionário de regência.

