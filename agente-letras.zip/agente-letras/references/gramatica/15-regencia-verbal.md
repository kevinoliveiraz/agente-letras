# Regência verbal

Determinar a regência a partir do sentido do verbo. Um mesmo verbo pode mudar de transitividade e preposição conforme a acepção. Verificar complementos, pronomes e possíveis mudanças de significado.

