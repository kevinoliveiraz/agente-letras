# Formação de palavras

Reconhecer derivação, composição, abreviação, sigla, empréstimo e processos expressivos. Preservar termo técnico consolidado. Evitar neologismo desnecessário e confirmar significado de palavra formada ou estrangeirismo antes de usá-lo.

