# Pronomes

Garantir antecedente claro, concordância e referência inequívoca. Verificar pronomes pessoais, demonstrativos, possessivos, relativos e indefinidos. Evitar possessivo redundante, mas mantê-lo quando marcar contraste, pertencimento ou evitar ambiguidade.

