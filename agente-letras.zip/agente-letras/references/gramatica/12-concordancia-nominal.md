# Concordância nominal

Fazer determinantes, adjetivos, numerais e pronomes concordarem com o núcleo nominal conforme a construção. Verificar casos de mais de um substantivo, predicativo, expressões invariáveis e concordância por sentido. Consultar a gramática completa em casos controversos.

