# Colocação pronominal

Avaliar próclise, mesóclise e ênclise segundo norma, registro e português brasileiro. Respeitar elementos atrativos no padrão formal. Não impor construção artificial em texto coloquial quando uma forma brasileira consolidada for adequada.

