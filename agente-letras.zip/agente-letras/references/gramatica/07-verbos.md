# Verbos

Verificar pessoa, número, tempo, modo, voz, aspecto e correlação temporal. Preferir verbo específico. Usar voz ativa quando o agente for relevante e voz passiva quando processo ou resultado forem o foco. Não alterar tempo verbal sem preservar a cronologia.

