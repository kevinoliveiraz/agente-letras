# Índice de gramática

Consultar o módulo correspondente antes de corrigir ou justificar uma construção. Para dúvida complexa, pesquisar também em `../gramatica-completa-bechara.md`.

1. Ortografia e acentuação
2. Classes de palavras
3. Formação de palavras
4. Substantivos e adjetivos
5. Artigos e numerais
6. Pronomes
7. Verbos
8. Advérbios
9. Preposições e conjunções
10. Sintaxe da oração
11. Coordenação e subordinação
12. Concordância nominal
13. Concordância verbal
14. Regência nominal
15. Regência verbal
16. Crase
17. Colocação pronominal
18. Pontuação
19. Semântica, coesão e coerência
20. Variação, norma e estilo

