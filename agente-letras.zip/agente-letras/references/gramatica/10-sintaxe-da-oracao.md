# Sintaxe da oração

Analisar sujeito, predicado, complementos, adjuntos, predicativos, aposto e vocativo. Corrigir estrutura sem transformar ordem marcada ou recurso estilístico em erro. Verificar se cada termo se liga ao núcleo pretendido.

