# Crase

Verificar a fusão da preposição a com artigo ou pronome iniciado por a. Testar regência, presença de determinante e possibilidade de substituição. Não usar crase antes de verbo, em regra antes de palavra masculina, nem onde não houver preposição e artigo simultaneamente. Considerar casos facultativos e locuções.

