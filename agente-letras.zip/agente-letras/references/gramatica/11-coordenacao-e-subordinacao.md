# Coordenação e subordinação

Evitar períodos com coordenações e subordinadas acumuladas. Separar ideias quando o ponto melhorar clareza. Manter período longo quando a progressão sintática for controlada e adequada ao gênero.

