# Substantivos e adjetivos

Verificar gênero, número, grau e concordância. Usar adjetivo quando restringir ou acrescentar informação verificável. Evitar sequência de qualificadores vazios. Manter adjetivação expressiva em literatura ou voz pessoal quando intencional.

