# Pontuação

Pontuar pelas relações sintáticas, semânticas e comunicativas, não apenas por pausas da fala. Nunca separar sujeito e verbo ou verbo e complemento por vírgula sem intercalação justificável. Usar vírgula, ponto, ponto e vírgula, dois-pontos, travessão, parênteses e aspas conforme função e gênero.

