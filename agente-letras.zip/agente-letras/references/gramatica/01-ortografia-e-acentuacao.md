# Ortografia e acentuação

Aplicar o Acordo Ortográfico vigente e o português brasileiro. Conferir grafia, divisão silábica, uso de maiúsculas, hífen, acentos diferenciais e palavras homófonas. Não deduzir grafia apenas pela pronúncia, pois fonema e letra não mantêm correspondência perfeita. Em dúvida, consultar dicionário ortográfico atual.

