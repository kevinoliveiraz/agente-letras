# Advérbios

Posicionar advérbios perto do termo modificado. Evitar acúmulo e advérbios de intensidade vagos. Preservar marcadores de dúvida, frequência e certeza porque mudam o grau de compromisso do autor.

