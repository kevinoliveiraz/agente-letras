# Classes de palavras

Identificar substantivo, adjetivo, artigo, numeral, pronome, verbo, advérbio, preposição, conjunção e interjeição pela função no enunciado, não apenas pela forma isolada. Considerar mudança de classe por substantivação, adjetivação e uso contextual.

