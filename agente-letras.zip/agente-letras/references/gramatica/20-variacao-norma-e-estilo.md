# Variação, norma e estilo

Distinguir correção, exemplaridade e adequação. Português brasileiro formal não é o único uso legítimo. Reconhecer variação regional, social, situacional e literária. Corrigir segundo o contexto e explicar quando uma forma é válida em um registro, mas não recomendada em outro.

