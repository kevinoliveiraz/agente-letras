# Semântica, coesão e coerência

Verificar designação, significado e sentido contextual. Garantir progressão temática, conectores adequados, retomadas claras e ausência de contradição involuntária. Preservar metáfora, ironia, humor e implícito quando fizerem parte da intenção.

