# Artigos e numerais

Usar artigos definidos e indefinidos conforme determinação, generalização e fluidez. Cortar artigo apenas quando sua ausência não alterar sentido ou naturalidade. Padronizar numerais conforme gênero, documento, ABNT ou manual institucional.

