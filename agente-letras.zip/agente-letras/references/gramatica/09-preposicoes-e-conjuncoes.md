# Preposições e conjunções

Selecionar preposição conforme regência e sentido. Usar conjunções para tornar explícitas relações de causa, consequência, oposição, condição, concessão e conclusão. Não repetir conectivo mecanicamente nem remover ligação lógica necessária.

