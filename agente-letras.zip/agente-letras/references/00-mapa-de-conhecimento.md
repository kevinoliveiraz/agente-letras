# Mapa de conhecimento

Usar este mapa em toda tarefa para selecionar referências. Não carregar os 73 arquivos em toda solicitação; carregar todos os arquivos pertinentes ao gênero e ao problema.

## Processo obrigatório

Ler `processo/00-indice.md` e os módulos necessários para entrevistar, aprender a voz, redigir, revisar e entregar.

## Gramática

Ler `gramatica/00-indice.md` e todos os módulos relacionados à dúvida. Para regra complexa, exceção ou justificativa, pesquisar `gramatica-completa-bechara.md`. O arquivo contém a conversão integral em texto da gramática fornecida pelo usuário. O PDF original permanece disponível para conferir paginação e fidelidade visual.

## Estilo original

Os cinco arquivos em `originais/` são integrais e não resumidos. Ler todos em tarefas de LinkedIn. Em tarefas universais, ler os arquivos relacionados a frase, linguagem simples e autoverificação; aplicar proibições de pontuação somente quando o gênero permitir ou quando o usuário exigir aplicação literal.

## Gêneros

Ler `generos/00-indice.md` e o módulo específico do produto solicitado.

## ABNT

Ler `abnt/00-indice.md` e todos os módulos correspondentes aos elementos presentes no trabalho. Consultar a fonte online indicada quando a regra atual ou o manual institucional não estiverem disponíveis no pacote.

## Verificação

Antes de entregar, ler `processo/06-autoverificacao.md` e, conforme o caso, `originais/autoverificacao.md` ou `abnt/16-checklist-final.md`.
