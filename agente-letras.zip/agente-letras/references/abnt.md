# Trabalhos acadêmicos e ABNT

## Prioridade

1. Manual, template ou exigência explícita da instituição.
2. Edital, periódico ou evento de destino.
3. Normas ABNT vigentes.
4. Guia institucional confiável, como o portal de Normas ABNT das Bibliotecas ESPM.

Não tratar guia institucional como texto oficial integral da ABNT. Verificar a versão vigente quando relevante.

Fonte prática indicada pelo usuário: `https://normas-abnt.espm.br/`. Consultar o portal quando a tarefa exigir detalhes de capa, folha de rosto, sumário, citações, referências, figuras, tabelas ou formatação. Não inventar conteúdo de página que não foi consultada.

## Capacidades

Formatar e revisar capa, folha de rosto, elementos pré-textuais, resumo, palavras-chave, abstract, listas, sumário, texto, referências, glossário, apêndices, anexos, numeração progressiva, citações, notas, figuras, tabelas, quadros, gráficos e equações.

## Configuração prática padrão

Usar somente quando a instituição não determinar outra configuração:

• papel A4;
• fonte legível aceita pela instituição, normalmente tamanho 12;
• fonte menor em citações longas, notas, paginação, legendas e fontes;
• no anverso, margens superior e esquerda de 3 cm e inferior e direita de 2 cm;
• corpo justificado e referências alinhadas à esquerda;
• entrelinhas 1,5 no corpo;
• espaço simples em citações longas, notas, referências, legendas e natureza do trabalho;
• citação longa com recuo conforme norma ou manual;
• contagem e exibição da paginação conforme exigência aplicável.

Não assumir fonte, recuo de parágrafo ou detalhe editorial quando houver template institucional.

## Integridade acadêmica

• Nunca inventar autor, título, página, edição, DOI, URL, data ou acesso.
• Nunca fabricar citação.
• Distinguir citação direta, paráfrase e contribuição do autor.
• Exigir página ou localização quando aplicável.
• Conferir correspondência entre citações e referências.
• Preservar grafia de citação direta e marcar intervenções segundo a norma.
• Alertar sobre paráfrase próxima demais do original.
• Não atribuir acesso a fonte não consultada.

## Arquivos

Quando solicitado a gerar DOCX ou PDF, aplicar estilos consistentes, sumário atualizável, quebras de seção, paginação e legendas. Renderizar e verificar visualmente antes da entrega conforme a habilidade de documentos ou PDF disponível.
