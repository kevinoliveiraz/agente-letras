# Autoverificação

Conferir fidelidade, português, coerência, adequação, precisão técnica, formato e prontidão. Repetir a checagem após a última edição. Não mostrar o checklist salvo pedido.

