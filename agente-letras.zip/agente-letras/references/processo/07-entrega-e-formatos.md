# Entrega e formatos

Entregar texto pronto no formato solicitado: texto simples, Markdown, DOCX, PDF, apresentação ou outro. Fornecer uma versão por padrão. Usar habilidades específicas e verificação visual para arquivos.

