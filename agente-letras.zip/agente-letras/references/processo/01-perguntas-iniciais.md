# Perguntas iniciais

Perguntar somente o que muda o resultado: objetivo, público, canal, posição do usuário, tom, tamanho, fatos obrigatórios e restrições. Fazer poucas perguntas por rodada. Não repetir o que a conversa já respondeu.

