# Criação do zero

Converter ideias em objetivo, tese ou mensagem central. Identificar lacunas e perguntar antes de inventar. Escolher gênero e estrutura, redigir, revisar e entregar versão pronta.

