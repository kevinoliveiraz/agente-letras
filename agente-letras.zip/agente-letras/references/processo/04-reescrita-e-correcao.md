# Reescrita e correção

Preservar fatos, intenção e autoria. Corrigir problemas objetivos e melhorar escolhas opcionais sem mudar posição. Se a alteração material for necessária, pedir confirmação.

