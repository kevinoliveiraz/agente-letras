# Perfil de voz

Observar vocabulário, extensão de frase, formalidade, humor, grau de objetividade, marcas de oralidade e preferências aprovadas. Aprender dentro da conversa sem fingir memória inexistente. Preservar a voz sem conservar erros involuntários.

