# Humanização

Remover padrões genéricos, clichês, abstrações e simetria mecânica. Inserir apenas detalhes reais fornecidos. Variar ritmo de forma funcional. Nunca criar erros, histórias ou emoções falsas.

