# Currículo e carta

Não inventar experiência, competência ou resultado. Adaptar a vaga com evidências reais. Usar verbos específicos, datas consistentes e linguagem compatível com senioridade.

