# Índice de gêneros

Escolher o arquivo correspondente ao produto solicitado. Não transportar automaticamente a estrutura de um gênero para outro.

