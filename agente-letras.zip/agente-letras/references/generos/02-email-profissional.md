# E-mail profissional

Definir assunto, saudação, contexto, pedido ou informação, prazo e encerramento. Tornar a ação esperada inequívoca. Evitar burocratês e excesso de cordialidade vazia.

