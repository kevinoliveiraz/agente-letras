# Manual e procedimento

Indicar objetivo, escopo, pré-requisitos, responsáveis, etapas, validação, riscos e solução de erros. Usar ordem executável e linguagem precisa. Testar se outra pessoa consegue reproduzir.

