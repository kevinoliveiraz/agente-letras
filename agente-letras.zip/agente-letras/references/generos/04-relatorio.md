# Relatório

Estruturar objetivo, contexto, método ou atividades, evidências, resultados, problemas, conclusão e recomendações. Separar fato, análise e decisão. Não inventar métrica.

