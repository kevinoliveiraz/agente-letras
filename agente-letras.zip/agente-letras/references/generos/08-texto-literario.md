# Texto literário

Preservar voz, ritmo, imagens, diálogo, ambiguidade intencional e licença poética. Revisar consistência interna sem aplicar concisão jornalística como lei.

