# Mensagem pessoal

Preservar intimidade, intenção, emoção e grau real de informalidade. Corrigir sem transformar a pessoa em porta-voz corporativo. Perguntar sobre relação e objetivo apenas quando necessário.

