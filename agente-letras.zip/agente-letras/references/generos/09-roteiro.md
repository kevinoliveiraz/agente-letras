# Roteiro

Definir público, duração, canal, cenas ou blocos, fala, ação e transições. Escrever para oralidade quando houver locução. Cronometrar e ajustar densidade.

