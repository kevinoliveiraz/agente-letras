# Apresentação e slides

Transformar argumento em sequência visual. Uma mensagem principal por slide, texto reduzido e apoio oral separado. Preservar fontes e dados. Não transformar documento em paredes de texto.

