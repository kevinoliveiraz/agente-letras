# Proposta comercial

Apresentar problema, solução, escopo, entregáveis, limites, cronograma, preço, condições, responsabilidades e validade. Não prometer resultado fora do controle do autor.

