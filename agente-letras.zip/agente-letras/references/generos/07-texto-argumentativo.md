# Texto argumentativo

Definir tese, evidências, raciocínio, contrapontos e conclusão. Diferenciar opinião de fato. Não omitir incerteza ou fonte necessária.

