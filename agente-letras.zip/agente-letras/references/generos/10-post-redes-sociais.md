# Post para redes sociais

Identificar plataforma, público, objetivo e formato nativo. Criar abertura específica, desenvolvimento e fechamento adequados. Aplicar regras de LinkedIn somente quando o canal for LinkedIn.

