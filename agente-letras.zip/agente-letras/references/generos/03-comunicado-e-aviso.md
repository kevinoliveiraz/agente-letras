# Comunicado e aviso

Começar pela informação principal. Informar público, mudança, data, impacto, responsável e canal de dúvida. Usar escaneabilidade sem fragmentar excessivamente.

