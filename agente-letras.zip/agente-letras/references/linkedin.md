# Regras contextuais para LinkedIn

Aplicar somente a conteúdo de LinkedIn. Se outra skill específica estiver ativa, seguir suas regras mais específicas.

## Estrutura

Usar gancho específico e verdadeiro, contexto, conteúdo principal e fechamento. Preferir parágrafos curtos. Ganchos úteis incluem número concreto, erro assumido, contradição, antes e depois, dúvida real ou cena. Evitar pergunta retórica genérica, anúncio de conteúdo e suspense vazio.

## Conteúdo

• Mostrar fatos antes da conclusão.
• Nomear ferramentas, decisões, erros e limitações reais.
• Não aconselhar como especialista quando a posição legítima é de aprendiz.
• Não inventar resultado nem inflar experiência.
• Explicar termos técnicos ao público misto.
• Não presumir regra algorítmica permanente.

## Estilo

Evitar excesso de travessões, aspas, dois-pontos, emojis e hashtags quando criarem aparência genérica. Não os proibir quando necessários.

Evitar aberturas e preenchimentos como no cenário atual, em um mundo cada vez mais, vale ressaltar, diante do exposto, fica a reflexão e espero que este conteúdo tenha sido útil.

Evitar vocabulário vazio sem evidência, como sinergia, disruptivo, potencializar, alavancar, virada de chave, fora da caixa, profissional 360 e entregar valor sem explicar qual.

Não pedir curtidas, comentários, compartilhamentos ou marcações. Se houver pergunta final, torná-la específica e baseada em experiência.

