# Pontuação, proibições e correções

Leia este arquivo antes de revisar qualquer texto. Ele amplia a lei da pontuação do SKILL.md e lista o que mais entrega texto de IA no LinkedIn.

## Parte 1. Travessão

### Por que a proibição existe

O travessão é o atalho preferido de quem escreve rápido. Ele aceita qualquer relação lógica entre duas partes da frase sem obrigar a pessoa a decidir qual é a relação. O resultado é um texto que parece pensado e não é. Tirar o travessão força a escolha entre ponto, vírgula, ponto e vírgula ou reescrita, e essa escolha melhora a frase toda vez.

Somando a isso: a alta densidade de travessões é hoje uma das assinaturas mais reconhecíveis de texto gerado por IA, e o algoritmo de 2026 penaliza conteúdo com cara de IA sem curadoria humana.

### Correções, caso a caso

**Aposto explicativo**

Errado: Comecei no estágio de suporte — minha primeira vaga em TI — sem saber abrir um chamado direito.
Certo: Comecei no estágio de suporte, minha primeira vaga em TI, sem saber abrir um chamado direito.

**Conclusão ou virada**

Errado: Testei três abordagens — nenhuma funcionou.
Certo: Testei três abordagens. Nenhuma funcionou.

**Contraste**

Errado: O código rodava na minha máquina — quebrava no servidor.
Certo: O código rodava na minha máquina; quebrava no servidor.

**Enumeração jogada no fim**

Errado: Usei três ferramentas — Git, Docker e Postman.
Certo: Usei três ferramentas: Git, Docker e Postman.
(Aqui os dois pontos são liberados, porque há enumeração real logo em seguida.)

**Fala de terceiro em diálogo**

Errado: O meu líder respondeu — refaz do zero.
Certo: O meu líder mandou refazer do zero.

**Intervalo numérico**

Errado: entre 30 – 60 minutos
Certo: entre 30 e 60 minutos

**Marcador de lista**

Errado:
- primeiro item
- segundo item

Certo:
• primeiro item
• segundo item

## Parte 2. Aspas

### Por que a proibição existe

Aspas costumam ser muleta. Servem para pedir desculpa por uma palavra mal escolhida, para dar ar de citação a algo que não foi dito assim, ou para marcar ironia que o texto não conseguiu construir sozinho. Sem elas, a frase precisa se sustentar pelo conteúdo.

### Correções, caso a caso

**Fala transcrita**

Errado: O recrutador disse: "buscamos alguém com sede de aprender".
Certo: O recrutador disse que buscava alguém disposto a aprender rápido.

**Aspas de ironia**

Errado: Passei o dia fazendo trabalho "estratégico".
Certo: Passei o dia renomeando planilha e conferindo campo repetido.

**Destaque de termo técnico**

Errado: Aprendi o que é "deploy" na prática.
Certo: Aprendi na prática o que é deploy, o momento em que o código sai do computador e vai para o servidor que o usuário acessa.

**Nome de produto ou curso**

Errado: Terminei o curso "Fundamentos de Redes".
Certo: Terminei o curso Fundamentos de Redes.

**Frase de efeito atribuída a alguém**

Errado: Como diz o ditado, "errar é humano".
Certo: Errar faz parte, e no meu caso o erro tinha nome e linha exata.

**Apelido de processo interno**

Errado: Rodei a nossa "gambiarra" de importação.
Certo: Rodei o script provisório de importação que o time mantém desde o ano passado.

## Parte 3. Dois pontos

### Auditoria obrigatória

Depois de escrever, localize cada `:` do texto e classifique. Só sobrevivem os que se encaixarem em um destes quatro casos:

1. **Enumeração real imediatamente depois.** Certo: Estudei três coisas nesta semana: rotas, middlewares e autenticação.
2. **Definição técnica.** Certo: Cache: memória temporária que guarda o que é acessado com frequência.
3. **Rótulo de dado ou comparação.** Certo: Antes: 12 minutos por chamado. Depois: 4 minutos.
4. **Cabeçalho de bloco ou slide de carrossel.** Certo: Slide 3. Erro comum: esquecer o índice na tabela.

Todo o resto vira ponto e vírgula ou ponto.

### Os cinco vícios mais comuns no LinkedIn

| Vício | Errado | Certo |
|---|---|---|
| Gancho com suspense | A lição que aprendi no primeiro mês: | A lição do meu primeiro mês custou quatro horas de retrabalho. |
| Conclusão pomposa | Fica a reflexão: consistência importa. | Fica a reflexão; consistência importa mais do que talento no começo. |
| Explicação preguiçosa | O motivo é simples: eu não li a documentação. | O motivo é simples; eu não li a documentação. |
| Rótulo emocional | Sentimento de hoje: gratidão. | Termino o dia grato por ter entendido onde estava travando. |
| Falsa enumeração | Existe um problema: ninguém explica isso para júnior. | Existe um problema. Ninguém explica isso para júnior. |

## Parte 4. Ponto e vírgula

Use como pausa mais forte que a vírgula em quatro situações:

- Trecho longo que já tem vírgulas e precisa de um respiro maior.
- Contraste entre duas orações. Certo: Eu achava que o gargalo era o banco; era a minha consulta.
- Segunda oração que justifica a primeira. Certo: Refiz o teste três vezes; queria eliminar a chance de erro meu.
- Itens longos de uma enumeração corrida.

Máximo de três por post. Se passar disso, troque alguns por ponto final. Quem escreve bem em português usa mais pontos do que qualquer outro sinal.

## Parte 5. Proibições de estilo

### Aberturas proibidas

No cenário atual; Em um mundo cada vez mais; Nos dias de hoje; Não é segredo que; É fato que; Recentemente tive a oportunidade de; Venho por meio deste; Gostaria de compartilhar com vocês; É com imensa alegria que; Neste post vou falar sobre.

### Preenchimento proibido

Vale ressaltar; Vale destacar; É importante salientar; É de suma importância; Sem dúvida alguma; Diante do exposto; Sendo assim; Em suma; Para finalizar; Espero que este conteúdo tenha sido útil; Fica a reflexão; O que você achou.

### Vocabulário de IA genérica proibido

Abordagem holística; ecossistema fora do sentido literal; sinergia; protagonismo; ressignificar; jornada como metáfora; disruptivo; mindset; empoderar; alavancar; potencializar; entregar valor sem dizer qual; mergulho profundo; virada de chave; fora da caixa; sede de aprender; profissional 360; soft skills sem exemplo concreto.

### Estruturas proibidas

- Frase de uma linha por parágrafo do começo ao fim, criando aquele efeito de poesia corporativa.
- Emoji no começo de toda linha.
- Mais de cinco hashtags.
- Pergunta retórica abrindo o post.
- Texto que só existe para anunciar que a pessoa vai postar mais.
- Qualquer variação de engagement bait, penalizada em até 60% de alcance. Comente sim se concorda; marque três colegas; deixa um emoji aqui embaixo; concorda ou discorda.

### Português

Português do Brasil, correto, sem erro de concordância, crase, regência, acentuação ou plural. Tom profissional e acessível, sem formalidade de ofício e sem gíria de rede social.
