# Estilo e frase

Princípios de redação aplicados ao post. A base vem da tradição do texto jornalístico brasileiro, especialmente do que Dad Squarisi e Arlete Salvador sistematizaram para quem escreve para leitor apressado. Serve bem ao LinkedIn pelo mesmo motivo que serve ao jornal: ninguém é obrigado a continuar lendo.

## 1. Frase curta manda

Uma ideia por frase. Quando o período começa a acumular oração, corte com ponto. O leitor de celular abandona antes do segundo travessão que ele não vê, porque travessão está proibido, e antes da terceira subordinada.

Como encurtar:

- **Troque gerúndio empilhado por verbo direto.** Em vez de fui testando e fui percebendo que estava errando, escreva testei e percebi o erro.
- **Transforme coordenada longa em período novo.** Onde couber um ponto, ponha o ponto.
- **Corte o já que, o sendo que, o uma vez que.** Quase sempre dá para separar as duas ideias.
- **Reduza oração adjetiva.** Pessoa que planta café é cafeicultor. Sistema que guarda dado temporário é cache.

Mistura de ritmo: frases curtas, de menos de doze palavras, alternadas com uma média. Dois períodos longos seguidos, nunca.

## 2. Palavra curta e simples vence a pomposa

Entre dois vocábulos, o mais curto. Entre dois curtos, o mais expressivo.

| Evitar | Usar |
|---|---|
| realizar a implementação | implementar |
| efetuar o pagamento | pagar |
| no âmbito da equipe | na equipe |
| proceder à análise | analisar |
| em virtude de | por |
| a fim de | para |
| possuir | ter |
| colocar | pôr |
| supracitado | citado antes |
| otimizar sem dizer o quê | reduzir tempo, cortar passo, tirar erro |

Palavra grande funciona como cortina entre quem escreve e quem lê. Em post de início de carreira, ela ainda soa como tentativa de parecer mais experiente, que é exatamente o efeito a evitar.

## 3. Forma positiva

Diga o que é, não o que não é. Não conseguir é falhar. Não lembrar é esquecer. Não entregar no prazo é atrasar.

Errado: Eu não tinha certeza de que a solução funcionaria.
Certo: Eu duvidava da solução.

## 4. Voz ativa

A voz ativa é mais curta, dispensa o verbo ser e soa mais firme.

Errado: O relatório foi refeito por mim depois da revisão.
Certo: Refiz o relatório depois da revisão.

Cuidado especial com a voz passiva de fuga, que esconde quem fez. Foram identificados problemas no processo. Quem identificou? Se foi a pessoa que assina o post, ela precisa aparecer.

## 5. Palavra concreta e específica

O específico vence o genérico. O definido vence o vago. O concreto vence o abstrato.

Errado: Foi um período de muito aprendizado.
Certo: Passei três meses no suporte de primeiro nível, atendendo em média 20 chamados por dia.

Cuidado com os verbos que servem para tudo e não dizem nada: fazer, colocar, ter, ver, acontecer, realizar. Cada um deles esconde um verbo melhor. Fazer um artigo é escrever. Colocar dinheiro no banco é depositar. Ter dor é sentir. O evento acontece amanhã é o evento começa amanhã.

Mesma regra para os substantivos que englobam o dicionário inteiro: coisa, questão, situação, aspecto, ponto.

## 6. Adjetivo com licença

Adjetivo só entra quando restringe o substantivo e acrescenta informação verificável. Mesa redonda, cabelo loiro, atleta canadense, servidor local.

Adjetivos que não informam nada e estão proibidos em post: incrível, fantástico, maravilhoso, enriquecedor, transformador, inesquecível, desafiador, gratificante, sensacional, único.

Teste: se removê-lo não muda o sentido, ele era enchimento.

Errado: Foi uma experiência incrível e enriquecedora.
Certo: Aprendi a ler log de erro sem depender de ninguém.

## 7. Lipoaspiração

Corte sem dó:

- **Artigo indefinido supérfluo.** Recebi (uma) tarefa nova. Fiz (um) teste rápido.
- **Possessivo desnecessário.** Quebrei (o meu) braço vira quebrei o braço. Antes de partes do corpo e de objetos óbvios, o possessivo sobra.
- **Demonstrativo peso pesado.** Aqueles que criticam vira quem critica.
- **Todos redundante.** Vou ao curso todas as terças vira vou ao curso às terças.
- **Que é, que foi, que era.** Brasília, que é a capital do país, vira Brasília, a capital do país.
- **Substantivo de data.** No mês de março vira em março. No ano de 2026 vira em 2026.

Escrever é cortar. O post fica melhor a cada palavra que sai sem levar informação junto.

## 8. Clareza acima de tudo

A frase precisa ser construída de modo que não só se entenda bem, mas que não se possa entender de outro jeito.

Aproxime o que se relaciona. O adjunto adverbial perto do termo a que se refere.

Ambíguo: Haverá um encontro sobre segurança no time de dados.
Claro: No time de dados, haverá um encontro sobre segurança.

## 9. Teste de legibilidade

Método clássico do texto jornalístico, adaptado ao português por Alberto Dines. Rode no parágrafo mais pesado do post quando ele parecer difícil.

1. Conte as palavras do parágrafo.
2. Conte as frases, cada uma terminando em ponto.
3. Divida palavras por frases; esse é o tamanho médio da frase.
4. Some esse número à quantidade de polissílabos do parágrafo.
5. Multiplique o total por 0,4.

Faixas de resultado:

| Índice | Leitura |
|---|---|
| 8 a 10 | excepcional |
| 11 a 15 | ótima |
| 16 a 19 | pequena dificuldade |
| 20 a 30 | difícil |
| acima de 31 | linguagem técnica ou nebulosa |

Alvo para post de LinkedIn: até 15. Passou de 19, quebre frases e troque polissílabo por palavra curta.

## 10. Emoji

No máximo dois por post, e só quando tiverem função de organização visual, nunca de emoção. Emoji abrindo toda linha é assinatura de post genérico. Nenhum emoji no gancho.
