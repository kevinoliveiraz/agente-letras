# Linguagem simples e termos técnicos

Ler sempre que o post tiver termo técnico. Vale principalmente para quem começa em tecnologia, mas o método serve a qualquer área.

## Por que isso importa no LinkedIn

O feed é misto. O mesmo post é lido por quem é da área, por recrutador, por professor e por gente de outro setor. O algoritmo distribui por afinidade de tema, não por conexão direta, então boa parte de quem vê o texto não tem o vocabulário completo.

Além disso, jargão sem explicação é o disfarce mais comum de quem não domina o assunto. Explicar bem um termo é prova de domínio; empilhar sigla é o contrário.

Como aspas estão proibidas, não existe a saída preguiçosa de marcar o termo com aspas e seguir em frente. Ou o termo é explicado, ou não entra.

## A regra dos três níveis

Antes de usar um termo técnico, decida em que nível ele está para o público do post.

| Nível | O que é | O que fazer |
|---|---|---|
| 1. Corrente | Já entrou no português comum. Site, e-mail, arquivo, senha, backup, planilha | Usar direto, sem explicação |
| 2. De área | Conhecido por quem é do setor, opaco para o resto. Deploy, cache, kernel, endpoint, pipeline | Usar e explicar em meia frase, na primeira ocorrência |
| 3. De especialidade | Só faz sentido dentro de um subcampo. Idempotência, quorum, sharding, backpressure | Só usar se for o assunto do post, e aí explicar direito |

Na dúvida, trate como nível 2. Explicar demais custa uma linha; explicar de menos custa o leitor.

## Como explicar em meia frase

O padrão é o termo seguido da função dele, no fluxo da frase, sem aspas e sem parênteses.

Errado: Fiz o deploy da aplicação.
Certo: Fiz o deploy da aplicação, o momento em que o código sai do meu computador e passa a rodar no servidor.

Errado: O problema estava no cache.
Certo: O problema estava no cache, a memória rápida que guarda o que é acessado com frequência para não buscar tudo de novo.

Errado: Configurei o firewall da rede.
Certo: Configurei o firewall, o filtro que decide qual tráfego entra e qual fica de fora da rede.

Quando o formato do post é a própria tradução técnica, os dois pontos ficam liberados no padrão de glossário.

Certo: API: conjunto de regras que permite dois programas conversarem sem que um precise conhecer o funcionamento interno do outro.

## Sigla

Primeira ocorrência com o nome por extenso, sigla em seguida, sem parênteses quando der para encaixar na frase. As demais ocorrências só com a sigla.

Certo: Trabalhei com acordo de nível de serviço, o SLA que define o prazo de resposta combinado com o cliente.

Isso também ajuda na busca, porque muita gente procura pelo nome por extenso e outra parte procura pela sigla.

## Analogia

Analogia funciona e é bem-vinda, com duas condições:

1. Ser do cotidiano de quem lê, não de outro campo técnico.
2. Vir acompanhada do ponto em que ela deixa de valer.

Certo: O nobreak funciona como um fôlego extra na queda de energia; ele dá tempo de salvar o trabalho e desligar direito, mas não substitui gerador nem segura o equipamento por horas.

A segunda parte é o que separa explicação boa de simplificação errada.

## Termos que quase sempre pedem explicação

Lista de checagem. Se um destes aparecer no post e o público não for exclusivamente técnico, explique na primeira ocorrência.

Acordo de nível de serviço, algoritmo, API, banco de dados, bug, cache, chatbot, cibersegurança, computação em nuvem, CPU, dashboard, debugging, DNS, endpoint, engenharia de software, ethernet, firewall, firmware, gateway, Git, help desk, hospedagem, HTML, inteligência artificial generativa, internet das coisas, IP, kernel, Kubernetes, LAN, machine learning, malware, nobreak, node, open source, proxy, query, QoS, RAM, roteador, segurança da informação, SQL, SSD, TCP/IP, trojan, URA, URL, UX, VPN, virtualização, VoIP, webinar, XML, YAML.

O glossário de termos técnicos de TI do Tribunal de Justiça do Acre, elaborado por Afonso Evangelista com modelagem técnica da DITEC e do LAPIS, é uma boa fonte de definições em linguagem simples para essa lista. Quando o arquivo estiver disponível na conversa, consulte a definição antes de escrever e reescreva com as próprias palavras, adaptando ao contexto do post.

## Erros de precisão que derrubam a credibilidade

Termo técnico usado fora do sentido é pior que termo não usado. Alguns pares que confundem com frequência:

- Memória RAM não é armazenamento. SSD e disco são armazenamento.
- CPU não é o gabinete. O gabinete é a caixa.
- Erro de programa é bug; falha de energia ou de peça é problema de hardware.
- Nem todo software malicioso é vírus. Vírus é um tipo de malware.
- Servidor é papel, não é sinônimo de computador grande.
- Nuvem é o computador de outra pessoa, com contrato. Não é lugar abstrato.

Na dúvida sobre o significado exato, não use o termo. Descreva o que aconteceu com palavras comuns. Ninguém perde ponto por clareza; todo mundo perde por usar palavra difícil errada.
