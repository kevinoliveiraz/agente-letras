# Estrutura do post e os dez formatos

## A arquitetura padrão

Todo post padrão tem quatro partes.

| Parte | Tamanho | Função |
|---|---|---|
| Gancho | 1 a 2 linhas, até 200 caracteres | fazer clicar em ver mais |
| Contexto | 2 a 4 linhas | situar quem lê. Onde, quando, o que estava em jogo |
| Miolo | 60% do post | o conteúdo de fato. Decisão, erro, comparação, procedimento |
| Fechamento | 2 a 4 linhas | o que fica para quem lê, mais a pergunta |

Entre cada bloco, linha em branco. Parágrafos de uma a três linhas. Nada de bloco compacto.

## O gancho

O gancho é a única parte que todo mundo vê. Ele precisa ser específico e verdadeiro. Não pode ser promessa que o texto não cumpre, porque abandono rápido conta contra o post.

### Seis tipos de gancho que funcionam

1. **Número concreto.** Levei quatro horas para descobrir que o problema era uma vírgula no arquivo de configuração.
2. **Erro assumido.** Subi o código sem testar. O ambiente caiu em dois minutos.
3. **Contradição.** Aprendi mais lendo log de erro do que assistindo aula.
4. **Antes e depois.** O processo levava 12 minutos. Hoje leva 4, e não foi por causa de ferramenta nova.
5. **Pergunta que a pessoa realmente tinha.** Ninguém me explicou por que o time revisa código antes de subir. Descobri na prática.
6. **Cena.** Primeiro dia de estágio. Abriram um chamado e eu não sabia nem o que era chamado.

### Ganchos proibidos

- Pergunta retórica de abertura. Você já se perguntou o que é ser júnior?
- Frase de efeito genérica. Nem todo aprendizado vem de um diploma.
- Suspense com dois pontos. A maior lição do meu primeiro emprego:
- Anúncio de conteúdo. Hoje vou falar sobre versionamento.
- Autodepreciação. Eu sei que sou só um iniciante, mas.

## O miolo

Regras:

- **Um fato por parágrafo.** Se o parágrafo tem duas ideias, quebre.
- **Nome próprio das coisas.** Ferramenta, comando, erro, arquivo, disciplina, capítulo. Especificidade é a moeda de quem não tem histórico.
- **Mostra antes de conclui.** Primeiro o que aconteceu, depois o que significa. Nunca o contrário.
- **Uma limitação assumida** em posts de projeto ou de aprendizado.
- **Lista só quando a informação for mesmo uma lista**, com marcador `•` ou numeração. Nunca hífen no começo da linha.

## O fechamento

Duas peças: o que fica e a pergunta.

O que fica é uma frase que o leitor conseguiria repetir para outra pessoa. Não é resumo do post; é o que sobra dele.

### A pergunta final

A pergunta precisa exigir experiência para ser respondida. Isso puxa comentários longos, que é o que faz o post avançar de estágio.

**Perguntas que funcionam:**
- Qual foi o erro que te ensinou mais rápido no seu primeiro ano?
- Que ferramenta você largou depois de testar de verdade, e por quê?
- Se você começasse hoje, o que estudaria primeiro?
- Como o seu time decide o que vira prioridade na sexta à tarde?

**Perguntas proibidas:**
- Concorda?
- O que você achou?
- Alguém mais passa por isso?
- Qualquer pedido de curtida, comentário, compartilhamento ou marcação de colega.

## Os dez formatos, em detalhe

### 1. Bastidor de construção
Estrutura: o que eu precisava resolver; a decisão que tomei; por que essa e não a outra; o que ficou pendente.
Cuidado: não vire diário. O leitor precisa levar a decisão embora, não a agenda.

### 2. Erro documentado
Estrutura: o que quebrou; o sintoma; a hipótese errada; a causa real; o que mudei no processo.
É o formato com melhor relação entre esforço e retorno para quem começa. Erro é específico por natureza, e específico é o que retém leitura.

### 3. Tradução técnica
Estrutura: o termo; o que ele significa em linguagem simples; um exemplo do cotidiano; onde a analogia deixa de valer.
Ver `linguagem-simples-e-termos-tecnicos.md`. A parte em que a analogia falha é o que separa este formato do post raso.

### 4. Comparativo testado
Estrutura: as duas opções; o critério de comparação; o que cada uma resolveu; a escolha e o contexto dela.
Regra dura: só compare o que a pessoa usou de fato. Comparativo de leitura de documentação não é comparativo testado.

### 5. Passo a passo reproduzível
Estrutura: o problema; os passos numerados; o resultado esperado; o erro mais comum no caminho.
Formato ideal para carrossel em PDF.

### 6. Leitura aplicada
Estrutura: o que li ou assisti; a ideia que aproveitei; onde apliquei; o que aconteceu.
Nunca resuma o material inteiro nem reproduza trechos. Uma ideia, uma aplicação.

### 7. Pergunta honesta ao setor
Estrutura: o contexto; o que já tentei; onde travei; a pergunta específica.
Este é o único formato em que a pergunta é o post inteiro. Mostrar o que já foi pesquisado é o que separa pergunta boa de preguiça.

### 8. Projeto de portfólio
Estrutura: o problema real que motivou; a escolha técnica principal; uma limitação assumida; o que faria diferente.
Link do repositório vai no primeiro comentário, nunca no corpo.

### 9. Mudança de opinião
Estrutura: o que eu achava; o que aconteceu; o que penso agora; o que ainda não sei.
Formato de alta retenção, porque tensão segura leitura.

### 10. Registro de evento ou certificação
Estrutura: o evento; a coisa concreta que aprendi; como vou usar isso na semana.
O aprendizado é o post. Certificado e foto são acessório. Sem esse aprendizado, não publique.

## Rotação

Não repita o formato do post anterior desta conversa. Se três posts seguidos partirem do mesmo tipo de gancho, mude o gancho antes de escrever o quarto.
