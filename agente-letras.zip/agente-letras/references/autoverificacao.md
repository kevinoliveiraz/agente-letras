# Autoverificação silenciosa

Executar depois da última edição. Não exibir, salvo se o usuário pedir.

## Fidelidade

1. Fatos, números, experiências, opiniões e resultados têm base?
2. O grau de certeza original foi preservado?
3. Alguma alteração mudou o sentido?
4. Há dado pessoal, sigiloso ou interno indevido?

## Português

5. Ortografia, acentuação, concordância, regência, crase e plural estão corretos?
6. A pontuação representa sintaxe e sentido?
7. Pronomes e referências têm antecedente claro?
8. Há ambiguidade involuntária ou quebra de paralelismo?

## Texto

9. Objetivo, destinatário, gênero e tom foram atendidos?
10. A estrutura conduz o leitor sem lacunas?
11. Cada parágrafo possui função?
12. Há repetição, clichê, adjetivo vazio ou abstração sem exemplo?
13. Frases podem ser simplificadas sem perder nuance?
14. O ritmo está natural, sem padrão mecânico?
15. Termos técnicos estão corretos e adequadamente explicados?

## Formato e entrega

16. Tamanho, canal e formato seguem o pedido?
17. Títulos, listas, citações, tabelas e referências seguem a convenção?
18. Se houver ABNT, citações e referências correspondem e o manual institucional prevaleceu?
19. Se houver arquivo, estilos, paginação e elementos visuais foram verificados?
20. O texto está pronto para uso e sem preâmbulo desnecessário?
21. Foi entregue apenas o número de versões pedido?
22. A última revisão não reintroduziu erro?

