# Escrita universal

## Clareza e frase

• Manter uma ideia principal por frase quando possível.
• Alternar frases curtas e médias. Evitar dois períodos excessivamente longos em sequência.
• Separar orações acumuladas quando um ponto melhorar a leitura.
• Aproximar termos relacionados para reduzir ambiguidade.
• Preferir voz ativa quando o agente da ação for conhecido e relevante.
• Usar voz passiva quando o foco legítimo for processo, resultado ou paciente da ação.

## Vocabulário

• Preferir palavra simples quando ela for igualmente precisa.
• Trocar locuções burocráticas por verbos diretos.
• Substituir fazer, colocar, ter, acontecer e realizar quando houver verbo mais específico.
• Evitar substantivos vagos quando um termo concreto couber.
• Usar adjetivo apenas quando restringir ou informar.
• Não remover palavra necessária apenas para encurtar.

## Concisão e naturalidade

Cortar repetição, redundância e preenchimento sem eliminar contexto, cortesia ou nuance. Evitar abertura genérica, conclusão pomposa, simetria excessiva, abstração sem exemplo, vocabulário corporativo vazio e frases de efeito sem fato.

Humanizar significa preservar intenção, variação de ritmo, escolhas autênticas e detalhes concretos. Não significa criar erros.

## Termos técnicos

Classificar em relação ao público:

1. Corrente: usar sem explicação quando for comum ao público.
2. De área: explicar brevemente na primeira ocorrência.
3. De especialidade: usar apenas quando necessário e explicar com precisão.

Apresentar sigla por extenso na primeira ocorrência quando necessário. Usar analogia cotidiana e indicar onde ela deixa de funcionar. Se houver dúvida sobre o termo, verificar ou descrevê-lo em linguagem comum.

Não confundir RAM com armazenamento, CPU com gabinete, malware com vírus, software com hardware ou servidor com tamanho físico de computador.

## Pontuação contextual

Usar travessão, aspas, dois-pontos, ponto e vírgula, parênteses e outros sinais conforme a gramática e o gênero. Evitar uso automático ou excessivo. Não proibir sinais necessários em diálogo, citação, análise linguística, literatura, ABNT ou documentação.

