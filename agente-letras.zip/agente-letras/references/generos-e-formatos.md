# Gêneros e formatos

Selecionar a estrutura antes de escrever. Não impor arquitetura de post a outro gênero.

## Comunicação pessoal

Mensagem, convite, pedido, resposta, agradecimento, reclamação ou conversa. Preservar intimidade e grau real de formalidade.

## Comunicação profissional

E-mail, comunicado, ata, relatório, procedimento, proposta, apresentação e documento empresarial. Priorizar objetivo, responsáveis, fatos, prazos, próximos passos e riscos. Evitar burocratês.

## Texto acadêmico

Artigo, trabalho, resumo, resenha, projeto, relatório de pesquisa e TCC. Exigir rigor conceitual, fontes verificáveis e distinção entre voz do autor e fonte. Ler `abnt.md`.

## Texto técnico e didático

Manual, tutorial, documentação, passo a passo e explicação. Indicar pré-requisitos, sequência, resultado esperado, riscos e erros comuns.

## Texto argumentativo

Apresentar tese, contexto, evidências, raciocínio, contrapontos e conclusão. Não inventar evidência nem esconder incerteza.

## Texto literário

Preservar voz, ritmo, imagem, ambiguidade intencional, diálogo e licença poética. Não aplicar concisão jornalística como regra rígida.

## Conteúdo digital

Adaptar ao canal: LinkedIn, blog, site, legenda, roteiro, carrossel ou newsletter. Para LinkedIn, ler `linkedin.md`.

## Estruturas reutilizáveis

• Bastidor de construção: problema, decisão, motivo, pendência.
• Erro documentado: sintoma, hipótese, causa, correção, prevenção.
• Tradução técnica: termo, explicação, exemplo, limite da analogia.
• Comparativo: opções, critérios, resultados, escolha contextual.
• Passo a passo: problema, pré-requisitos, etapas, resultado, erro comum.
• Leitura aplicada: fonte, ideia, aplicação, resultado.
• Pergunta fundamentada: contexto, tentativa, bloqueio, pergunta específica.
• Projeto: problema, escolha, implementação, limitação, próximo passo.
• Mudança de opinião: posição anterior, evidência, posição atual, dúvida restante.
• Registro de aprendizagem: contexto, aprendizado concreto, aplicação.

