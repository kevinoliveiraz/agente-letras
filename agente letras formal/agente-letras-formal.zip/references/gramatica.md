# Base gramatical — Agente Letras

> Referência interna original para criação, revisão e edição de textos em português brasileiro.

## Finalidade

Este arquivo reúne critérios gramaticais e editoriais para orientar os agentes do projeto Agente Letras. Não reproduz uma gramática comercial nem substitui obras especializadas. Sua função é oferecer uma base própria, distribuível e prática para análise linguística, correção e tomada de decisão durante a escrita.

As regras devem ser aplicadas considerando gênero textual, público, canal, intenção comunicativa e grau de formalidade. Nem toda diferença em relação à norma-padrão constitui erro: variação linguística, oralidade e escolhas estilísticas legítimas devem ser reconhecidas.

## Princípios gerais

1. Preservar o sentido e os fatos fornecidos pelo usuário.
2. Distinguir erro, inadequação contextual, variação legítima e escolha estilística.
3. Corrigir apenas o necessário quando o pedido for correção.
4. Não transformar preferência estilística em regra absoluta.
5. Não inventar fatos, opiniões, experiências, fontes ou resultados.
6. Priorizar clareza, coerência e adequação sem apagar a voz do autor.
7. Em dúvida relevante, consultar referência externa confiável quando disponível.
8. Não reproduzir conteúdo protegido de obras externas.

---


# 1. Ortografia e escrita


## 1.1 Ortografia vigente

Aplicar a grafia vigente do português brasileiro. Conferir a forma lexical antes de alterar uma palavra apenas por estranhamento visual.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 1.2 Acentuação

Verificar tonicidade, estrutura da palavra e regras aplicáveis. Não acrescentar ou retirar acento por simples analogia.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 1.3 Maiúsculas e minúsculas

Usar maiúsculas em nomes próprios e contextos convencionais; evitar capitalização decorativa fora do gênero.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 1.4 Hífen

Tratar o hífen como questão ortográfica dependente da formação lexical; consultar fonte normativa atual quando houver dúvida.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 1.5 Palavras semelhantes

Distinguir formas homófonas ou graficamente próximas pelo significado e pela função contextual.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 1.6 Siglas e abreviações

Preservar formas institucionalmente estabelecidas e expandir na primeira ocorrência quando necessário à compreensão.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


# 2. Estrutura das palavras


## 2.1 Radical e base

Reconhecer relações entre famílias de palavras sem transformar análise morfológica em substituição lexical automática.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 2.2 Prefixação

Observar como prefixos modificam sentido e como a grafia vigente organiza sua união à base.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 2.3 Sufixação

Reconhecer formação de classes e valores avaliativos, preservando efeitos estilísticos pretendidos.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 2.4 Flexão

Distinguir formação de nova palavra de flexões de gênero, número, pessoa, tempo e modo.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 2.5 Composição

Avaliar compostos segundo grafia vigente, lexicalização e função no contexto.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


# 3. Classes nominais


## 3.1 Substantivo

Identificar núcleos nominais e suas relações de gênero, número, determinação e referência.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 3.2 Gênero gramatical

Não confundir gênero gramatical automaticamente com sexo ou identidade do referente.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 3.3 Número

Verificar singular e plural segundo a forma lexical e as relações de concordância.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 3.4 Artigos

Usar artigos definidos e indefinidos conforme determinação e referência no contexto.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 3.5 Adjetivos

Verificar concordância, posição, escopo e eventual mudança de sentido.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 3.6 Numerais

Distinguir quantidade, ordem e outras funções numéricas conforme o gênero textual.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


# 4. Pronomes


## 4.1 Pessoais

Verificar pessoa discursiva, função sintática e coerência entre interlocutores.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 4.2 Demonstrativos

Usar coerentemente nas relações espaciais, temporais e textuais, considerando o português brasileiro contemporâneo.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 4.3 Possessivos

Observar ambiguidades sobre o possuidor ou relação expressa.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 4.4 Relativos

Garantir antecedente recuperável, função sintática adequada e preposição quando exigida.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 4.5 Indefinidos

Preservar o grau de generalização ou indeterminação realmente pretendido.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 4.6 Referência pronominal

Reformular quando um pronome puder apontar para mais de um referente relevante.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


# 5. Verbos


## 5.1 Pessoa e número

Relacionar a forma verbal ao sujeito gramatical e à pessoa discursiva.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 5.2 Tempo

Manter coerência entre presente, passado e futuro e entre os pontos temporais do texto.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 5.3 Indicativo

Usar de acordo com os valores de factualidade e apresentação assumidos pela construção.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 5.4 Subjuntivo

Reconhecer valores de hipótese, possibilidade, desejo, condição e dependência contextual.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 5.5 Imperativo

Adequar instruções, pedidos e comandos ao grau de força exigido pelo gênero.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 5.6 Infinitivo

Avaliar flexão a partir da estrutura e do sujeito, evitando decisões mecânicas.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 5.7 Gerúndio

Tratá-lo como forma legítima; corrigir apenas usos que criem inadequação ou falta de clareza.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 5.8 Particípio

Observar emprego em tempos compostos, passivas e construções adjetivas.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 5.9 Voz ativa e passiva

Não converter automaticamente entre vozes quando a mudança altera foco informativo.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 5.10 Impessoalidade

Identificar construções sem sujeito antes de decidir a flexão.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 5.11 Locuções verbais

Analisar auxiliar e verbo principal como unidade de tempo, aspecto, modalidade ou voz.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


# 6. Advérbios, preposições e conectores


## 6.1 Advérbios

Identificar o elemento modificado e aproximar o advérbio dele quando a posição gerar ambiguidade.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 6.2 Intensificadores

Não aumentar ou reduzir intensidade sem apoio no texto do usuário.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 6.3 Negação

Verificar o alcance da negação para impedir inversão de sentido.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 6.4 Preposições

Determinar relações sintáticas e semânticas e respeitar preposições exigidas por regência.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 6.5 Conjunções

Escolher conectores pela relação lógica efetivamente existente.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 6.6 Marcadores discursivos

Preservar marcadores conversacionais quando adequados à voz e ao gênero.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


# 7. Sintaxe da oração


## 7.1 Sujeito

Identificar o termo ou estrutura com que o verbo estabelece concordância quando houver sujeito.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 7.2 Sujeito oculto

Não inserir pronome apenas para explicitar referente já recuperável.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 7.3 Sujeito indeterminado

Distinguir indeterminação, ocultação e impessoalidade.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 7.4 Predicado

Analisar a estrutura declarada em torno do verbo e suas relações.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 7.5 Objeto direto

Reconhecer complemento verbal conforme a regência e a construção.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 7.6 Objeto indireto

Reconhecer complemento verbal introduzido pela preposição exigida.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 7.7 Complemento nominal

Distinguir complementação de nomes da complementação verbal.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 7.8 Adjunto adnominal

Reconhecer determinação e caracterização ligadas ao nome.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 7.9 Adjunto adverbial

Reconhecer circunstâncias sem classificar mecanicamente toda expressão preposicionada.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 7.10 Predicativo

Identificar característica ou estado atribuído a sujeito ou objeto.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 7.11 Aposto

Pontuar conforme função explicativa, especificativa ou enumerativa.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 7.12 Vocativo

Delimitar o termo usado para chamar ou dirigir-se ao interlocutor.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


# 8. Período composto


## 8.1 Coordenação aditiva

Representar soma sem inventar consequência.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 8.2 Coordenação adversativa

Usar quando existe contraste ou oposição relevante.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 8.3 Coordenação alternativa

Representar alternativas reais.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 8.4 Coordenação conclusiva

Usar quando a segunda unidade decorre logicamente da anterior.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 8.5 Coordenação explicativa

Introduzir explicação ou justificativa compatível com a estrutura.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 8.6 Subordinadas substantivas

Reconhecer funções equivalentes às de sintagmas nominais.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 8.7 Subordinadas adjetivas

Distinguir valor restritivo e explicativo, inclusive pela pontuação.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 8.8 Subordinadas adverbiais

Identificar relações como causa, condição, concessão, finalidade, tempo e consequência.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 8.9 Correlação

Manter pares correlativos e paralelismo suficiente.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


# 9. Concordância verbal


## 9.1 Regra geral

Fazer o verbo concordar com o núcleo do sujeito, considerando pessoa e número.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 9.2 Sujeito composto

Avaliar núcleos, pessoa, posição e relação semântica antes da flexão.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 9.3 Expressões partitivas

Reconhecer casos de variação legítima e não transformar preferência em erro.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 9.4 Porcentagens

Analisar número expresso, especificador e estrutura completa.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 9.5 Pronome relativo

Identificar antecedente e função antes de decidir a concordância.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 9.6 Haver existencial

Em emprego existencial impessoal, não criar sujeito inexistente.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 9.7 Fazer temporal

Em construções impessoais de tempo decorrido, preservar a impessoalidade.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 9.8 Verbo ser

Considerar construções especiais de identificação, horas, datas e quantidades.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


# 10. Concordância nominal


## 10.1 Regra geral

Relacionar determinantes, adjetivos e modificadores aos substantivos correspondentes.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 10.2 Vários substantivos

Considerar gênero, número, posição e abrangência do modificador.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 10.3 Adjetivo anteposto

Analisar a relação efetiva e o efeito estilístico antes de alterar.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 10.4 Adjetivo posposto

Verificar se o adjetivo se refere a um ou vários núcleos.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 10.5 Formas invariáveis

Não flexionar automaticamente palavras de emprego adverbial ou lexicalizado.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


# 11. Regência


## 11.1 Regência verbal

Determinar a construção pelo verbo, pelo sentido assumido e pelo complemento.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 11.2 Mudança de sentido

Reconhecer que um verbo pode selecionar construções diferentes conforme o significado.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 11.3 Preposição exigida

Não eliminar preposição necessária apenas para aproximar a escrita da fala.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 11.4 Regência nominal

Reconhecer complementos selecionados por substantivos, adjetivos e advérbios.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 11.5 Relativos e regência

Manter a preposição exigida quando o relativo exerce função que a requer.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 11.6 Uso e formalidade

Distinguir uso corrente de exigências de registro formal sem condenar toda variação.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


# 12. Crase


## 12.1 Princípio

O acento grave sinaliza crase em contextos específicos; não é consequência automática de uma palavra feminina.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 12.2 Análise estrutural

Verificar preposição exigida e elemento compatível com a fusão.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 12.3 Locuções

Conferir construções convencionais quando houver dúvida.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 12.4 Demonstrativos

Reconhecer possíveis fusões com formas demonstrativas em estruturas que exigem preposição.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 12.5 Topônimos

Verificar se o nome de lugar admite artigo na construção usada.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 12.6 Facultatividade

Reconhecer contextos em que mais de uma realização é aceita.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 12.7 Ausência de crase

Não usar acento grave quando os elementos necessários à fusão não estiverem presentes.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


# 13. Colocação pronominal


## 13.1 Próclise

Reconhecer a colocação anterior ao verbo e sua forte presença no português brasileiro.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 13.2 Ênclise

Usar quando a estrutura e o registro a comportarem.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 13.3 Mesóclise

Reconhecer seu caráter restrito e marcado; não introduzir solenidade sem necessidade.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 13.4 Naturalidade

Não converter sistematicamente construções brasileiras naturais em formas excessivamente solenes.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 13.5 Registro

Distinguir exigência formal, tradição normativa e uso efetivo conforme o gênero.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


# 14. Pontuação


## 14.1 Princípio

Usar pontuação para organizar relações sintáticas, informativas e discursivas, não apenas pausas respiratórias.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 14.2 Vírgula em enumeração

Separar itens coordenados quando a estrutura exigir.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 14.3 Vocativo

Delimitar o chamamento para evitar leitura sintática incorreta.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 14.4 Aposto

Delimitar estruturas explicativas quando necessário.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 14.5 Sujeito e verbo

Evitar vírgula entre sujeito e verbo sem estrutura intercalada que a justifique.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 14.6 Verbo e complemento

Evitar separação indevida entre verbo e complemento essencial.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 14.7 Adjuntos

Avaliar posição, extensão e valor informativo antes de pontuar.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 14.8 Restrição e explicação

A pontuação pode alterar o alcance de uma oração relativa; preservar o sentido pretendido.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 14.9 Ponto final

Encerrar unidades de sentido sem fragmentar artificialmente o raciocínio.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 14.10 Dois-pontos

Introduzir explicação, enumeração, fala ou desenvolvimento relacionado.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 14.11 Ponto e vírgula

Separar unidades relacionadas com autonomia intermediária.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 14.12 Travessão

Usar em diálogo, intercalação ou destaque; evitar como vício automático de escrita.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 14.13 Parênteses

Reservar para informação acessória quando essa organização for útil.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 14.14 Aspas

Usar em citação, metalinguagem ou outros empregos convencionais; evitar destaque gratuito.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 14.15 Reticências

Usar para suspensão ou efeito discursivo compatível com o gênero.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 14.16 Interrogação

Marcar perguntas diretas e efeitos interrogativos adequados.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 14.17 Exclamação

Adequar intensidade ao canal sem inventar entusiasmo.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


# 15. Ordem dos termos


## 15.1 Ordem frequente

Reconhecer padrões comuns sem tratá-los como única ordem possível.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 15.2 Inversão

Aceitar inversões motivadas por sintaxe, foco, ritmo ou estilo.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 15.3 Adjuntos

Posicionar modificadores de forma a reduzir ambiguidades.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 15.4 Informação conhecida e nova

Usar a ordem para organizar progressão informativa quando isso ajudar a leitura.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 15.5 Ambiguidade

Reorganizar somente quando a posição permitir leituras materialmente diferentes.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


# 16. Coesão e coerência


## 16.1 Referência

Garantir que retomadas sejam recuperáveis.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 16.2 Conectores

Representar relações lógicas reais.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 16.3 Repetição lexical

Preservar repetição quando ela garante precisão; reduzir quando for vazia.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 16.4 Elipse

Aceitar omissão recuperável e restaurar elementos quando houver ambiguidade.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 16.5 Progressão

Fazer cada trecho desenvolver, exemplificar, contrastar ou concluir algo identificável.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 16.6 Não contradição

Sinalizar incompatibilidades internas sem inventar qual afirmação é verdadeira.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 16.7 Causalidade

Não converter sequência ou correlação em causa.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 16.8 Grau de certeza

Preservar fato, hipótese, possibilidade, opinião, estimativa e intenção.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 16.9 Escopo

Tratar com cuidado palavras absolutas como sempre, nunca, todos e somente.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


# 17. Clareza e legibilidade


## 17.1 Períodos longos

Dividir quando a quantidade de relações impedir leitura segura.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 17.2 Períodos curtos

Evitar fragmentação excessiva de um raciocínio contínuo.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 17.3 Ambiguidade lexical

Preferir formulação mais precisa quando duas leituras forem relevantes.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 17.4 Ambiguidade sintática

Reposicionar modificadores ou repetir referentes quando necessário.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 17.5 Redundância

Retirar repetição sem função e preservar repetição enfática ou técnica.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 17.6 Paralelismo

Manter estruturas equivalentes suficientemente compatíveis em listas e comparações.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


# 18. Variação e registro


## 18.1 Norma-padrão

Aplicar quando o contexto exigir escrita formal monitorada, sem tratá-la como única variedade legítima.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 18.2 Uso informal

Aceitar construções coloquiais compatíveis com canal e intenção.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 18.3 Regionalidade

Não apagar regionalismos compreensíveis apenas por não serem neutros.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 18.4 Oralidade

Preservar quando for recurso legítimo de mensagem, diálogo, roteiro ou voz pessoal.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 18.5 Gírias

Manter quando adequadas ao público e à voz; adaptar quando incompatíveis com o contexto.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 18.6 Formalização

Formalizar somente no grau solicitado ou exigido.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


# 19. Semântica aplicada


## 19.1 Sinonímia

Não assumir equivalência total entre sinônimos; preservar nuance e registro.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 19.2 Polissemia

Determinar o sentido pelo contexto antes de substituir.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 19.3 Figuração

Reconhecer metáforas e expressões idiomáticas sem literalizá-las automaticamente.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 19.4 Pressuposição

Não acrescentar pressupostos que o usuário não assumiu.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 19.5 Implicatura

Não transformar interpretação provável em afirmação explícita sem autorização.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 19.6 Intensidade

Não fortalecer ou enfraquecer afirmações sem base.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


# 20. Estilo e naturalidade


## 20.1 Voz do autor

Preservar escolhas lexicais, formalidade e ritmo quando não houver erro ou pedido de transformação.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 20.2 Clichês

Evitar fórmulas genéricas que ocupam espaço sem acrescentar informação.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 20.3 Jargão

Usar termos técnicos quando necessários; não sofisticar artificialmente.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 20.4 Ritmo

Variar estruturas quando isso melhorar leitura sem criar outra personalidade.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 20.5 Ênfase

Adequar destaque ao canal e à intenção.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 20.6 Humanização

Buscar naturalidade por contexto e voz, nunca por erros propositais.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


# 21. Preservação de autoria


## 21.1 Fatos

Não adicionar informação factual ausente.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 21.2 Experiências

Não atribuir vivências, competências ou resultados não fornecidos.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 21.3 Opiniões

Não transformar explicação neutra em opinião do usuário.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 21.4 Sentimentos

Não atribuir entusiasmo, orgulho, frustração ou emoção não declarada.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 21.5 Resultados

Não inventar métricas, impacto, aprovação ou sucesso.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 21.6 Certeza

Não transformar possibilidade ou intenção em afirmação categórica.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 21.7 Intervenção mínima

Em correção, preservar o que funciona; ampliar alterações apenas conforme o objetivo.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


# 22. Adequação por gênero


## 22.1 Mensagem pessoal

Priorizar naturalidade, intenção e relação entre interlocutores.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 22.2 E-mail profissional

Priorizar objetivo, contexto suficiente, cortesia funcional e clareza do pedido.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 22.3 LinkedIn

Priorizar legibilidade, autenticidade e fatos efetivamente fornecidos.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 22.4 Documentação técnica

Priorizar precisão, sequência, consistência terminológica, condições e resultados.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 22.5 Tutorial

Organizar pré-requisitos, passos, verificações e possíveis erros.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 22.6 Texto acadêmico

Priorizar precisão conceitual e regras institucionais ou normativas fornecidas.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 22.7 Argumentação

Separar tese, razões, evidências, objeções e conclusão sem fabricar evidências.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 22.8 Texto criativo

Permitir flexibilização consciente da norma para voz, personagem, ritmo e efeito.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 22.9 Conteúdo de site

Equilibrar clareza, escaneabilidade, identidade e objetivo funcional.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


# 23. Decisão editorial


## 23.1 Erro objetivo

Corrigir quando houver problema claro pertinente ao registro exigido.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 23.2 Variação aceita

Preservar ou escolher pela adequação contextual.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 23.3 Preferência

Não apresentar gosto editorial como obrigação gramatical.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 23.4 Dúvida

Consultar referência adequada ou sinalizar incerteza relevante.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 23.5 Conflito

Priorizar sentido, pedido explícito, modelo obrigatório e gênero.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


## 23.6 Modelo institucional

Respeitar modelo fornecido quando ele for requisito da tarefa.

### Como analisar

A decisão deve partir da frase completa. Identifique a função do elemento, sua relação com os termos próximos, o significado pretendido e o registro do texto. Uma alteração só deve ser feita quando resolver um problema real ou quando fizer parte da transformação solicitada.

### Procedimento

1. Leia a unidade completa antes de corrigir.
2. Identifique o núcleo ou relação gramatical relevante.
3. Verifique se existe erro ou apenas uma alternativa possível.
4. Considere público, gênero, canal e grau de formalidade.
5. Preserve fatos e grau de certeza.
6. Faça a menor intervenção suficiente quando o pedido for correção.
7. Em reescrita, amplie a intervenção somente para atender ao objetivo.

### Exemplos próprios

- Forma contextual: `A equipe terminou a revisão e enviou o arquivo no mesmo dia.`
- Mudança indevida: acrescentar `com excelentes resultados` sem que o usuário tenha informado qualquer resultado.
- Variação: se duas construções forem legítimas, a escolha deve considerar naturalidade e adequação, não uma preferência arbitrária.

### Erros de revisão a evitar

- aplicar uma regra sem identificar a estrutura;
- formalizar automaticamente;
- trocar palavras corretas apenas para variar o vocabulário;
- criar informação para tornar a frase mais completa;
- apagar marcas legítimas da voz do autor;
- tratar toda variação como erro;
- alterar o sentido para obter uma frase estilisticamente mais elegante.

### Nota para o agente

Quando houver mais de uma solução correta, não é necessário explicar todas por padrão. Escolha a mais adequada ao pedido. Se a diferença puder alterar sentido, posicionamento, grau de certeza ou identidade textual, preserve a forma original ou peça esclarecimento.


# Apêndice A — Pontuação: diagnóstico rápido

## Antes de inserir uma vírgula

Pergunte:

1. Estou separando itens coordenados?
2. Existe vocativo?
3. Existe termo intercalado?
4. Existe oração explicativa?
5. A estrutura deslocada pede delimitação?
6. A vírgula separaria sujeito e verbo?
7. A vírgula separaria verbo e complemento essencial?
8. A retirada ou inserção muda o sentido?

A pausa percebida durante a leitura pode ajudar a interpretar, mas não é critério suficiente por si só.

## Antes de usar dois-pontos

Verifique se a segunda unidade desenvolve algo anunciado pela primeira: explicação, enumeração, fala, consequência discursiva ou esclarecimento.

## Antes de usar travessão

Verifique se há diálogo, intercalação ou destaque funcional. Não preferir travessão automaticamente quando vírgulas, parênteses, dois-pontos ou um novo período forem mais naturais.

# Apêndice B — Concordância: diagnóstico rápido

1. Localize o verbo.
2. Pergunte se a construção possui sujeito.
3. Localize o núcleo do sujeito.
4. Ignore temporariamente termos intercalados.
5. Determine pessoa e número.
6. Verifique se a construção pertence a caso especial.
7. Só então escolha a forma verbal.

Para concordância nominal, localize primeiro o substantivo ou os substantivos abrangidos pelo modificador. A proximidade gráfica não garante que duas palavras estejam sintaticamente ligadas.

# Apêndice C — Regência e crase: diagnóstico rápido

A regência deve ser resolvida antes da crase.

1. Identifique a palavra regente.
2. Determine seu sentido na frase.
3. Verifique se exige preposição.
4. Identifique o termo seguinte.
5. Verifique se esse termo admite artigo ou outra forma capaz de se fundir com a preposição.
6. Somente depois decida sobre o acento grave.

Nunca aplicar a regra simplista de que palavra feminina recebe crase.

# Apêndice D — Ambiguidade

Uma ambiguidade precisa ser corrigida quando:

- impede saber quem realizou uma ação;
- permite conclusões factuais diferentes;
- altera obrigação, condição ou prazo;
- muda a pessoa a quem uma informação se refere;
- modifica o alcance de negação ou quantificação;
- compromete instruções ou procedimentos.

Uma ambiguidade deliberada em literatura, humor ou publicidade pode ser recurso estilístico.

# Apêndice E — Preservação factual

Durante criação ou revisão, separar:

## Informação fornecida

Pode ser usada como fato dentro do texto, respeitando o grau de certeza apresentado.

## Inferência plausível

Não deve ser atribuída ao usuário como fato.

## Conhecimento externo

Só deve ser acrescentado quando o pedido permitir e quando houver base confiável adequada.

## Elemento estilístico

Pode reorganizar a apresentação, mas não modificar o conteúdo factual.

Exemplo:

Entrada: `Estou estudando JavaScript e fiz meu primeiro projeto.`

É possível melhorar organização e clareza. Não é possível concluir, sem informação adicional, que o projeto teve usuários, gerou resultados, demonstrou domínio profissional ou confirmou uma vocação.

# Apêndice F — Escala de intervenção

## Nível 1 — Correção

Corrigir ortografia, gramática e pontuação necessárias. Preservar vocabulário, estrutura e voz sempre que possível.

## Nível 2 — Revisão

Além da correção, resolver problemas de clareza, coesão, repetição e organização.

## Nível 3 — Reescrita

Reformular frases e estrutura para atender a um objetivo, mantendo fatos e intenção.

## Nível 4 — Adaptação

Modificar registro, gênero, público, canal ou formato, sem inventar conteúdo.

## Nível 5 — Criação assistida

Transformar informações, ideias e contexto em uma nova versão textual. A liberdade estrutural aumenta, mas os limites factuais permanecem.

# Apêndice G — Norma, variação e estilo

Antes de classificar algo como erro, pergunte:

- viola uma regra necessária ao registro solicitado?
- é construção legítima do português brasileiro?
- pertence a um registro informal?
- é regionalismo compreensível?
- é escolha estilística?
- foi usada deliberadamente em fala de personagem?
- existe mais de uma forma aceita?

O agente deve corrigir erros, não uniformizar todas as pessoas em uma única voz.

# Apêndice H — Checklist gramatical completo

- [ ] Grafia
- [ ] Acentuação
- [ ] Maiúsculas e minúsculas
- [ ] Hífen quando relevante
- [ ] Flexões nominais
- [ ] Flexões verbais
- [ ] Concordância verbal
- [ ] Concordância nominal
- [ ] Regência verbal
- [ ] Regência nominal
- [ ] Crase
- [ ] Colocação pronominal
- [ ] Referência pronominal
- [ ] Tempos e modos verbais
- [ ] Estrutura das orações
- [ ] Relações entre orações
- [ ] Pontuação
- [ ] Ordem dos termos
- [ ] Conectores
- [ ] Coesão
- [ ] Coerência
- [ ] Ambiguidades
- [ ] Grau de certeza
- [ ] Negação e escopo
- [ ] Registro
- [ ] Naturalidade
- [ ] Preservação da voz
- [ ] Preservação dos fatos
- [ ] Adequação ao gênero
- [ ] Adequação ao canal
- [ ] Extensão adequada
- [ ] Ausência de acréscimos não autorizados

# Apêndice I — Referências externas

Esta base foi escrita para funcionar de forma independente e ser distribuída com o Agente Letras.

O usuário pode adicionar uma gramática externa à qual possua acesso legítimo para aprofundar consultas. A obra externa não deve ser redistribuída dentro do projeto sem autorização ou licença compatível.

Quando uma referência externa estiver disponível:

1. use-a para conferir casos específicos;
2. não copie passagens extensas para os arquivos do projeto;
3. formule as orientações do agente em texto próprio;
4. preserve eventuais divergências relevantes em vez de inventar consenso;
5. mantenha separada a licença da obra externa da licença do Agente Letras.

# Apêndice J — Hierarquia de decisão

Quando orientações competirem, priorizar:

1. integridade factual;
2. pedido explícito do usuário;
3. contexto fornecido;
4. modelo obrigatório;
5. gênero e canal;
6. correção gramatical necessária;
7. clareza;
8. preservação da voz;
9. preferência estilística.

Uma preferência estilística nunca autoriza inventar um fato.

# Nota de distribuição

Este documento é uma base textual original criada para o projeto Agente Letras. Foi concebido para poder acompanhar a distribuição pública do projeto sem incorporar o texto integral de gramáticas comerciais.

Referências externas podem complementar esta base, desde que seus direitos autorais e termos de uso sejam respeitados.
